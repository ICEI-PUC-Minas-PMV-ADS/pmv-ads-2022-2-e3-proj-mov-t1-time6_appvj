import React from 'react';
import {
  Text,
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';

export default function App() {
  return (
    <View style={styles.background}>

      <Image
        style={styles.imagem}
        source={require('./assets/tourTicket.png.png')}
      />
    <Image
        style={styles.imagem2}
        source={require('./assets/porto-de-galinhas.jpg')}
      />
      <TextInput
        style={styles.input}
        placeholder="Local de Destino"
        autoCorrect={false}
        onChangeText={() => {}}
      />

       <TextInput
        style={styles.input}
        placeholder="Mês da Viagem"
        autoCorrect={false}
        maximumDate
        onChangeText={() => {}}
      />

      <TextInput
        style={styles.input}
        placeholder="Data da Viagem"
        autoCorrect={false}
        onChangeText={() => {}}
      />

      <TextInput
        style={styles.input}
        placeholder="Meio de transporte"
        autoCorrect={false}
        onChangeText={() => {}}
      />

      <TouchableOpacity style={styles.btnSubmit}>
        <Text style={styles.text}>Cadastrar Viagem</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },

  imagem: {
    width: 80,
    height: 80,
    justifyContent: 'start',
      },

   imagem2: {
    width: 405,
    height: 250,
    justifyContent: 'start',
    marginBottom: 15,
    borderRadius: 8,
  },

  input: {
    flex: 0.0,
    alignContent: 'center',
    justifyContent: 'space-between',
    width: '90%',
    color: '#488F51',
    marginBottom: 15,
    fontSize: 17,
    borderRadius: 8,
    borderStyle: 'solid',
    borderColor: '#488F51',
    padding: 10,
    placeholder: 'white',
  },

  btnSubmit: {
    width: '90%',
    backgroundColor: '#488F51',
    opacity : 0.9,
    color: 'white',    
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
    borderRadius: 8,
    fontSize: 20,
    
  },

  text:{
    color: 'white',
    fontSize: 17, 
    opacity : 0.9,
  }

});
